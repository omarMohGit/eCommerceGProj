
<template>
  <CheckOut/>
</template>

<script>
import CheckOut from '../components/CheckOut.vue'
export default {
    name: 'CheckoutView',
    components: {CheckOut},

}
</script>

<style>

</style>