<template>
 

  

  
</template>
<script>


export default {
  name: 'AdminPageView',
  components:{
 
    
  }
}
</script>


<style >

</style>
