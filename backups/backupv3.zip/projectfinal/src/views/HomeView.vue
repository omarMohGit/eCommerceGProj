<template>
<body>

    <!-- header section starts  -->

    <header>
       

        <div class="header-1">
            <a href="#" class="logo"><img src="../assets/mainlogo.jpeg" width="172" height="72"></a>
            <form action="" class="search-box-container">
                <input type="search" id="search-box" placeholder="search here...">
                <label for="search-box" class="fas fa-search"></label>
            </form>
        </div>

        <div class="header-2">
            <div id="menu-bar" class="fas fa-bars"></div>
            <nav class="navbar">
                <a href="#home">home</a>
                <a href="#category">category</a>
                <a href="#product">product</a>
                <a href="#contact">contact</a>
                <a href="/login">login</a>
                <a href="#cart">cart</a>

            </nav>



        </div>


    </header>
     <div class="time">
            <h1 id="time"></h1>
            <img class="sun" src="../assets/Sun.svg.png" alt="">
            <img class="moon" src="../assets/moon.png" alt="">
    </div>

    <!-- header section ends -->



    <!-- home section starts  -->

    <section class="home" id="home">

        <div class="image">
            <img src="../assets/home-img.png" alt="">
        </div>

        <div class="content">
            <span>Spring Essential Collection is here</span>
            <h3>limited Quantities</h3>
            <a href="#product" class="btn">shop now</a>
        </div>

    </section>

    <!-- home section ends -->


    <!-- apparel broll video starts-->

    <div class="hero__video ">
        <video id="hpvid"
            src="https://player.vimeo.com/external/588444787.hd.mp4?s=90da50731af4498974fe4bea47aea1bd2ac017ac&amp;profile_id=175"
            autoplay="" loop="" muted="" playsinline=""></video>
    </div>

    <!-- apparel broll video ends-->


    <!-- category section starts  -->
     <section class="category" id="category">

        <h1 class="heading">shop by <span>category</span></h1>

        <div class="box-container">

            <div class="box">
                <h3>Shirts</h3>
                <p>upto 50% off</p>
                <img src="" alt="">
                <a href="#product" class="btn">shop now</a>
            </div>
            <div class="box">
                <h3>Hoodies</h3>
                <p>upto 44% off</p>
                <img src="" alt="">
                <a href="#hoodies" class="btn"  >shop now</a>
            </div>
            <div class="box">
                <h3>Pants</h3>
                <p>upto 35% off</p>
                <img src="" alt="">
                <a href="#pants" class="btn">shop now</a>
            </div>
            

        </div>

    </section>

    <!-- category section ends -->


    <!-- Nike Shoe Video starts-->
    <!-- Nike Shoe Video ends-->


    <!-- product section starts  -->

    <section class="product" id="product">
        

        <h1 class="heading">latest <span>products</span></h1>

        <div class="box-container">

            <div class="box product">
                <span class="discount" id="disc1">-33%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>

                <img class="pics" src="../assets/product-1.jpg">
                <h3>
                    <span class="iName">
                        Smile Face Print Thermal Lined Oversized Sweatshirt
                    </span>
                </h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>

                <div class="productInfo">
                    <span class="cost" id="price1">$109.99</span>
                    <button class="btn  add" type="button"> Add To Cart</button>
                </div>
            </div>






            <div class="box product">
                <span class="discount" id="disc2">-30%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>

                <img class="pics" src="../assets/product-4.jpg">
                <h3>
                    <span class="iName">
                        Become The Change Thermal Pullover
                    </span>
                </h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>

                <div class="productInfo">
                    <span class="cost" id="price2">$79.99</span>
                    <button class="btn  add" type="button">Add To Cart</button>
                </div>
            </div>
            <!---- --->


            <div class="box product">
                <span class="discount" id="disc3">-15%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>

                <img class="pics" src="../assets/product-7.jpg">
                <h3>
                    <span class="iName">
                        Mushroom Toad Sweatshirt
                    </span>
                </h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>

                <div class="productInfo">
                    <span class="cost" id="price3">$59.99</span>
                    <button class="btn  add" type="button">Add To Cart</button>
                </div>
            </div>



            <div  class="box product" id="hoodies">
                <span class="discount" id="disc4">-45%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>

                <img class="pics" src="../assets/product-2.jpg">
                <h3>
                    <span class="iName">
                        Letter & Expression Print Drawstring Thermal Hoodie
                    </span>
                </h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>

                <div class="productInfo">
                    <span class="cost" id="price4">$79.99</span>
                    <button class="btn  add" type="button">Add To Cart</button>
                </div>
            </div>

            <div class="box product">
                <span class="discount" id="disc5">-25%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>

                <img class="pics" src="../assets/product-5.jpg">
                <h3>
                    <span class="iName">
                        Good Vibes with Butterfly Hoodie
                    </span>
                </h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>

                <div class="productInfo">
                    <span class="cost" id="price5">$69.99</span>
                    <button class="btn  add" type="button">Add To Cart</button>
                </div>
            </div>

            <div class="box product">
                <span class="discount" id="disc6">-15%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>

                <img class="pics" src="../assets/product-9.jpg">
                <h3>
                    <span class="iName">
                        Dragon eating good Thermal Hoodie
                    </span>
                </h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>

                <div class="productInfo">
                    <span class="cost" id="price6">$99.99</span>
                    <button class="btn  add" type="button">Add To Cart</button>
                </div>
            </div>

            <div class="box product" id="pants">
                <span class="discount" id="disc7">-35%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>

                <img class="pics" src="../assets/product-7.webp">
                <h3>
                    <span class="iName">
                        Houndstooth Print Drawstring Waist Pants
                    </span>
                </h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>

                <div class="productInfo">
                    <span class="cost" id="price7">$110.00</span>
                    <button class="btn  add" type="button">Add To Cart</button>
                </div>
            </div>

            <div class="box product">
                <span class="discount" id="disc8">-25%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>

                <img class="pics" src="../assets/product-8.webp">
                <h3>
                    <span class="iName">
                        Drawstring Waist Patched Detail Pants
                    </span>
                </h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>

                <div class="productInfo">
                    <span class="cost" id="price8">$50.00</span>
                    <button class="btn  add" type="button">Add To Cart</button>
                </div>
            </div>
            <div class="box product">
                <span class="discount" id="disc9">-20%</span>
                <div class="icons">
                    <a href="#" class="fas fa-heart"></a>
                    <a href="#" class="fas fa-share"></a>
                    <a href="#" class="fas fa-eye"></a>
                </div>

                <img class="pics" src="../assets/product-9.webp">
                <h3>
                    <span class="iName">
                        Drawstring Waist Colorblock Cargo Pants
                    </span>
                </h3>
                <div class="stars">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star-half-alt"></i>
                </div>

                <div class="productInfo">
                    <span class="cost" id="price9">$45.00</span>
                    <button class="btn  add" type="button">Add To Cart</button>
                </div>
            </div>

        </div>

    </section>

   

    <!-- product section ends -->

    <!-- revuenue chart section starts  -->

    <!-- revuenue chart section ends -->

    <!-- contact section starts  -->

    <section class="contact" id="contact">

        <h1 class="heading"> <span>contact</span> us </h1>

        <form action="">

            <div class="inputBox">
                <input type="text" placeholder="name">
                <input type="email" placeholder="email">
            </div>

            <div class="inputBox">
                <input type="number" placeholder="number">
                <input type="text" placeholder="subject">
            </div>

            <textarea placeholder="message" name="" id="" cols="30" rows="10"></textarea>

            <input type="submit" value="send message" class="btn">

        </form>

    </section>

    <!-- contact section ends -->

    <!-- newsletter section starts  -->

    <section class="newsletter">

        <h3>subscribe us for latest updates</h3>

        <form action="">
            <input class="box" type="email" placeholder="enter your email">
            <input type="submit" value="subscribe" class="btn">
        </form>

    </section>

    <!-- newsletter section ends -->

    <!-- footer section starts  -->
   <section class="container content-section" id="cart">
        <div class="lineup">
            <span class="cart-item cart-header x">Item</span>
            <span class="itemCost cart-header x">Price</span>
            <span class="cart-quantity cart-header x">Quantity</span>
        </div>
        <div class="carti">
        </div>
        <div class="cart-total">
            <strong class="cart-total-title">Total</strong>
            <span class="fTotal">$0</span>
        </div>
        <button class="btn btn-primary buy" type="button">PURCHASE</button>
    </section>

    <section class="footer">

        <div class="box-container">

            <div class="box">

                <p></p>
                <div class="share">
                    <a href="https://www.facebook.com" class="btn fab fa-facebook-f"></a>
                    <a href="https://www.twitter.com" class="btn fab fa-twitter"></a>
                    <a href="https://www.instagram.com" class="btn fab fa-instagram"></a>
                </div>
            </div>

            <div class="box">
                <h3>our location</h3>
                <div class="links">
                    <a>canada</a>
                    <a>USA</a>
                    <a>france</a>
                    <a>japan</a>
                    <a>russia</a>
                </div>
            </div>

            <div class="box">
                <h3>quick links</h3>
                <div class="links">
                    <a>home</a>
                    <a>category</a>
                    <a>product</a>
                    <a>deal</a>
                    <a>contact</a>
                </div>
            </div>

            <div class="box">
                <h3>download app</h3>
                <div class="links">
                    <a>google play</a>
                    <a>window xp</a>
                    <a>app store</a>
                </div>
            </div>

        </div>

        <h1 class="credit"> created by <span> CUTIES, </span> | all rights reserved! </h1>

    </section>
    <!-- footer section ends -->



















   

</body>
</template>


<script>
 import $ from "jquery";
 

export default {
  name: 'HelloWorld',
  mounted(){
    //Here I used Ajax to access the server to update the information for our products
  var ourRequest = new XMLHttpRequest();
  ourRequest.open('GET', 'http://127.0.0.1:2500/UpdatePrices',true);
  ourRequest.onload = function(){
      let data = JSON.parse(this.responseText);
      
      for(let i =1; i<=9; i++){
          var price = data[i-1]["price"];
          console.log(data[i-1]["price"]);
          document.getElementById(`price${i}`).innerHTML= price;
      }

      for(let i =1; i<=9; i++){
          var sale = data[i-1]["sale"];
          console.log(data[i-1]["sale"]);
          document.getElementById(`disc${i}`).innerHTML= sale + "%";
      }

  }
  //This actually sends our request to the webpage hosted by our server
  ourRequest.send();

  function butt() {
      var del = document.getElementsByClassName('delButt')
      var numItem = document.getElementsByClassName('totalAmountItem')
      var atc = document.getElementsByClassName('add')
      for (var a = 0; a < del.length; a++) {
          var delButtAll = del[a]
          delButtAll.addEventListener('click', deleteItemC)
      }


      for (var b = 0; b < numItem.length; b++) {
          var amounts = numItem[b]
          amounts.addEventListener('change', quantityChanged)
      }

      for (var c = 0; c < atc.length; c++) {
          var added = atc[c]
          added.addEventListener('click', addToCartClicked)
      }

      document.getElementsByClassName('buy')[0].addEventListener('click', purchaseClicked)
  }
  function addToCartClicked(event) {
      var atc = event.target
      var item = atc.parentElement.parentElement

      var name = item.getElementsByClassName('iName')[0].innerText
      var price = item.getElementsByClassName('cost')[0].innerText
      var pic = item.getElementsByClassName('pics')[0].src

      addItemToCart(name, price, pic)
      updateCartTotal()
  }




  function deleteItemC(event) {
      var deleted = event.target
      deleted.parentElement.parentElement.remove()

      updateCartTotal()
  }

  function quantityChanged(event) {
      var quantityN = event.target
      if (quantityN.value <= 0) {
          quantityN.value = 1
      }
      updateCartTotal()
  }


  function addItemToCart(name, price, pic) {
      var items = document.getElementsByClassName('carti')[0]
      var cartIN = items.getElementsByClassName('inside')

      var row = document.createElement('div')
      row.classList.add('lineup')


      for (var d = 0; d < cartIN.length; d++) {
          if (cartIN[d].innerText == name) {
              return
          }
      }


      var display
          = `
          <div class="cart-item x">
              <img class="reframe" src="${pic}">
              <span class="inside">${name}</span>
          </div>
          <span class="itemCost x">${price}</span>
          <div class="cart-quantity x">
              <input class="totalAmountItem" type="number" value="1">
              <button class="btn delButt" type="button">Remove</button>
          </div>`

      row.innerHTML = display


      items.append(row)
      row.getElementsByClassName('delButt')[0].addEventListener('click', deleteItemC)
      row.getElementsByClassName('totalAmountItem')[0].addEventListener('change', quantityChanged)
  }

  function updateCartTotal() {
      var cont = document.getElementsByClassName('carti')[0]
      var totalRows = cont.getElementsByClassName('lineup')
      var total = 0


      for (var e = 0; e < totalRows.length; e++) {
          var row = totalRows[e]
          var priceTag = row.getElementsByClassName('itemCost')[0]
          var quantTag = row.getElementsByClassName('totalAmountItem')[0]

          var price = parseFloat(priceTag.innerText.replace('$', ''))
          var quantity = quantTag.value
          total = total + (price * quantity)
      }


      total = Math.round(total * 100) / 100
      document.getElementsByClassName('fTotal')[0].innerText = '$' + total

  }
  function purchaseClicked() {
      window.location.href = "/checkout";
  }
    
    async function load() {
    let url = 'https://www.timeapi.io/api/Time/current/zone?timeZone=Canada/Eastern';
    let obj = await (await fetch(url)).json();
    var time = obj.time;
    var hour = obj.hour;
    var minute = obj.minute;
    console.log(obj);
    console.log(time);
    console.log(hour);
    console.log(minute);
    document.getElementById("time").innerHTML = time;

    if (hour >= 7 && minute >= 0) {
        console.log(hour + " " + minute + "hey")

        $('.sun').toggle('slow');

    }
    else if (hour <= 20 && minute >= 0) {
        $('.moon').toggle('slow');
    }


}

  load();
  butt()

    }

}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped src='../assets/styles/styles.css'>
  @import url("https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css");
     
</style>