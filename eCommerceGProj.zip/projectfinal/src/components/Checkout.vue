<template>
  
</template>
<script>
import HelloWorld from "@/components/HelloWorld.vue";
export default {
  name: 'CheckOut',
  components:{
   
    
    
  }
}
</script>


<style lang="scss">

</style>
